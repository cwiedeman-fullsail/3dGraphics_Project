var group___operators =
[
    [ "G_PASS", "group___operators.html#ga555afa9e1cf5bf0e971d5ade089087e7", null ],
    [ "G_FAIL", "group___operators.html#ga073044fdc45cc5147393f088d56ebc7b", null ],
    [ "GW::operator+", "group___operators.html#ga485e0ff64a524066fd91c07e8ce409ec", null ],
    [ "GW::operator-", "group___operators.html#ga88254010245aaddb6ac8460a27800907", null ]
];