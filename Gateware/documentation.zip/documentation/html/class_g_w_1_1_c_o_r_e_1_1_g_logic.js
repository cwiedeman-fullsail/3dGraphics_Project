var class_g_w_1_1_c_o_r_e_1_1_g_logic =
[
    [ "Create", "class_g_w_1_1_c_o_r_e_1_1_g_logic.html#aae7d313b10cf887f264e60896542b6d8", null ],
    [ "Assign", "class_g_w_1_1_c_o_r_e_1_1_g_logic.html#a20a9804db79009bbf13c48f26e6970cd", null ],
    [ "Invoke", "class_g_w_1_1_c_o_r_e_1_1_g_logic.html#adbaa5aadc75682ade76b801ee45e8fc2", null ]
];