var class_g_w_1_1_c_o_r_e_1_1_g_event_queue =
[
    [ "Create", "class_g_w_1_1_c_o_r_e_1_1_g_event_queue.html#a4778621e392d4fb4d612d61b6ca3d002", null ],
    [ "Peek", "class_g_w_1_1_c_o_r_e_1_1_g_event_queue.html#a933ce6de8849c5066a53b90eb0c5f5fc", null ],
    [ "Max", "class_g_w_1_1_c_o_r_e_1_1_g_event_queue.html#ad4699b87add4ac35055e9dc0add49b43", null ]
];