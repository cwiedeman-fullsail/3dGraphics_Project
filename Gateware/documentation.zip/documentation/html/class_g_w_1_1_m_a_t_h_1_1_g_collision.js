var class_g_w_1_1_m_a_t_h_1_1_g_collision =
[
    [ "GCollisionCheck", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5", [
      [ "ERROR_NO_RESULT", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5a1f7c402ecf04b66580b84611b64cc019", null ],
      [ "ABOVE", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5ac2d92b81beeac9bfc89fb870c1a20767", null ],
      [ "BELOW", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5aa25949e21299b84cc33c4b00c740f08f", null ],
      [ "NO_COLLISION", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5a874a40b8eb0a1602fae9e93767a85f08", null ],
      [ "COLLISION", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#aaa1cd21a913c20e338cea128ae62eba5afc3ca10632f0c7aa3aaea07a234377db", null ]
    ] ],
    [ "Create", "class_g_w_1_1_m_a_t_h_1_1_g_collision.html#a258baa0b767a83c9f61cbee7b9a0cf59", null ]
];