var searchData=
[
  ['operationcount_0',['operationCount',['../struct_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon_1_1_e_v_e_n_t___d_a_t_a.html#a6cf73e6ea46caabf90f28e8e37819ec2',1,'GW::SYSTEM::GDaemon::EVENT_DATA']]]
];
