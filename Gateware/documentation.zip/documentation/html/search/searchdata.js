var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy",
  1: "degtu",
  2: "g",
  3: "abcdefgilmnopqrstuvw",
  4: "cdefghiklmnopqstwxy",
  5: "deg",
  6: "abcdefhiklmnoprstuw",
  7: "agmos",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

