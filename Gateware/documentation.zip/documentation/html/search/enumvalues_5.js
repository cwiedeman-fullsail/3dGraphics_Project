var searchData=
[
  ['failure_0',['FAILURE',['../group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a36fc6065a3e970bc3e6b2e59da52bf2a',1,'GW']]],
  ['feature_5funsupported_1',['FEATURE_UNSUPPORTED',['../group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617ab2a458b4cd30043189c97da3172fbc53',1,'GW']]],
  ['file_5fnot_5ffound_2',['FILE_NOT_FOUND',['../group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617acd54d99c8efb3c2db794197045f5b83c',1,'GW']]],
  ['format_5funsupported_3',['FORMAT_UNSUPPORTED',['../group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617aad7e3cfdd56d166a8b33ddc7563b61aa',1,'GW']]],
  ['fullscreenbordered_4',['FULLSCREENBORDERED',['../group___system_defines.html#ggad117891e556631f842625c348d36a071a53f85450b2d0eb8b81333f2048b8adb5',1,'GW::SYSTEM']]],
  ['fullscreenborderless_5',['FULLSCREENBORDERLESS',['../group___system_defines.html#ggad117891e556631f842625c348d36a071a49d6a9c65f7c67a6d51afffe99f39555',1,'GW::SYSTEM']]],
  ['function_5fdeprecated_6',['FUNCTION_DEPRECATED',['../group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a7b29591f7774d4d4dc0e0fe825dd32fc',1,'GW']]]
];
