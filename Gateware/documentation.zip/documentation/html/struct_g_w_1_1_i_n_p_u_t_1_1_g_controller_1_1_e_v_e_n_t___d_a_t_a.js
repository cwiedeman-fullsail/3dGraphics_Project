var struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a =
[
    [ "controllerIndex", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html#ad091b5c4b541c35c9cd76bafdf0d453c", null ],
    [ "controllerID", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html#ae77ee7d7f5f9f04126678e24b1f51d85", null ],
    [ "inputCode", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html#a758549bcf2127ed2ff45c7c336ee08a4", null ],
    [ "inputValue", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html#aa3409e62073cb7eb86934d7d8d5be974", null ],
    [ "isConnected", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html#a1438542a238e100599c20eb538aff580", null ]
];