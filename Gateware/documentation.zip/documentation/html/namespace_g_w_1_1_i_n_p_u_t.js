var namespace_g_w_1_1_i_n_p_u_t =
[
    [ "GBufferedInput", "class_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input" ],
    [ "GController", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller" ],
    [ "GInput", "class_g_w_1_1_i_n_p_u_t_1_1_g_input.html", "class_g_w_1_1_i_n_p_u_t_1_1_g_input" ],
    [ "GControllerType", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328e", [
      [ "GENERAL", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328eab61773b9b3968a9988d765d728985862", null ],
      [ "PS3", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328eabf2aed0e93e0880bb2a174e757657eb1", null ],
      [ "PS4", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328ea868be3cc5f2f3bae4e2fdea9d202d7fe", null ],
      [ "PS5", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328ea60a37aaf61b5fabdbe32269086faaafe", null ],
      [ "STEAM", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328ea53a74f4dae64c5696e0a379357df2cf4", null ],
      [ "SWITCHPRO", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328eac3c3974e7670740afdb3ea4d10d91a2e", null ],
      [ "XBOX360", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328ea688a2af8f931a5da9f09d1e2fe527eaa", null ],
      [ "XBOXONE", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328ea859211d2aa5e386cbc138f4eef8d5e0c", null ],
      [ "XBOXSERIES", "namespace_g_w_1_1_i_n_p_u_t.html#a71953016d06d4a92ad420eb5500b328eac2d550beea0230cdf2aad316c64c9d3e", null ]
    ] ]
];