var class_g_w_1_1_c_o_r_e_1_1_g_interface =
[
    [ "Create", "class_g_w_1_1_c_o_r_e_1_1_g_interface.html#a42b7b64c7e41b05e3a9a5629a6856794", null ],
    [ "Share", "class_g_w_1_1_c_o_r_e_1_1_g_interface.html#abd779fa8304afb36b9f1c8f897b40a8c", null ],
    [ "Relinquish", "class_g_w_1_1_c_o_r_e_1_1_g_interface.html#ada67a040adb9755a631ae19eda3ebcbd", null ],
    [ "Mirror", "class_g_w_1_1_c_o_r_e_1_1_g_interface.html#a6e112efa1f87f7d3bf3f04cbc72f24ed", null ]
];